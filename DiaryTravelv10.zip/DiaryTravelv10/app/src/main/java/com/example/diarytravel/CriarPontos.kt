package com.example.diarytravel

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.diarytravel.db.AppDatabase
import com.example.diarytravel.entities.Local
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CriarPontos : AppCompatActivity() {

    private var isMenuVisible = false
    private lateinit var editTitulo: EditText
    private lateinit var editRegiao: EditText
    private lateinit var editComentario: EditText
    private lateinit var btnGuardar: MaterialButton
    private lateinit var btnCancelar: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar_pontos)

        // Menu lateral
        val btnToggleMenu = findViewById<ImageButton>(R.id.btnMenuLateral)
        val containerMenu = findViewById<View>(R.id.containerMenuLateral)

        btnToggleMenu.setOnClickListener {
            if (isMenuVisible) {
                supportFragmentManager.findFragmentById(R.id.containerMenuLateral)?.let {
                    supportFragmentManager.beginTransaction().remove(it).commit()
                }
                containerMenu.visibility = View.GONE
            } else {
                supportFragmentManager.beginTransaction()
                    .replace(R.id.containerMenuLateral, FragmentoMenuLateral())
                    .commit()
                containerMenu.visibility = View.VISIBLE
            }
            isMenuVisible = !isMenuVisible
        }

        // Ir para perfil
        findViewById<ImageButton>(R.id.btnIrParaPerfil).setOnClickListener {
            startActivity(Intent(this, PerfilActivity::class.java))
        }

        // Inicializar inputs
        editTitulo = findViewById(R.id.editTextTitulo)
        editRegiao = findViewById(R.id.editTextRegiao)
        editComentario = findViewById(R.id.editTextComentario)
        btnGuardar = findViewById(R.id.btnGuardar)
        btnCancelar = findViewById(R.id.btnCancelar)

        val db = AppDatabase.getDatabase(this)

        btnGuardar.setOnClickListener {
            val titulo = editTitulo.text.toString()
            val regiao = editRegiao.text.toString()
            val comentario = editComentario.text.toString()

            // Validação
            if (titulo.isBlank() || regiao.isBlank()) {
                Toast.makeText(this, "Preencha o título e a região!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val novoLocal = Local(
                titulo = titulo,
                regiao = regiao,
                comentario = comentario.ifBlank { null }
            )

            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    db.LocalDao().inserirLocal(novoLocal)
                }
                finish()
            }
        }

        btnCancelar.setOnClickListener {
            finish()
        }
    }
}
