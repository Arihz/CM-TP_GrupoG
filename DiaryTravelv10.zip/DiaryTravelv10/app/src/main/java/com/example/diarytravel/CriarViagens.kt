package com.example.diarytravel

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.diarytravel.db.AppDatabase
import com.example.diarytravel.entities.Viagem
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date

class CriarViagens : AppCompatActivity() {

    private var isMenuVisible = false
    private lateinit var editTitulo: EditText
    private lateinit var editData: EditText
    private lateinit var editClassificacao: EditText
    private lateinit var editCategoria: EditText
    private lateinit var editLocalizacao: EditText
    private lateinit var editComentario: EditText
    private lateinit var btnAdicionar: MaterialButton
    private lateinit var btnCancelar: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_criar_viagens)

        //Menu
        val btnToggleMenu = findViewById<ImageButton>(R.id.btnMenuLateral)
        val containerMenu = findViewById<View>(R.id.containerMenuLateral)

        //logica que permite abrir e fechar o menu
        btnToggleMenu.setOnClickListener {
            if (isMenuVisible) {
                supportFragmentManager.findFragmentById(R.id.containerMenuLateral)?.let {
                    supportFragmentManager.beginTransaction()
                        .remove(it)
                        .commit()
                }
                containerMenu.visibility = View.GONE
            } else {
                supportFragmentManager.beginTransaction()
                    .replace(R.id.containerMenuLateral, FragmentoMenuLateral())
                    .commit()
                containerMenu.visibility = View.VISIBLE
            }
            isMenuVisible = !isMenuVisible
        }

        // Botão Travel
        findViewById<ImageButton>(R.id.btnIrParaPerfil).setOnClickListener {
            startActivity(Intent(this, PerfilActivity::class.java))
        }

        // Inicializar views
        editTitulo = findViewById(R.id.editTextTitulo)
        editData = findViewById(R.id.editTextData)
        editClassificacao = findViewById(R.id.editTextClassificacao)
        editCategoria = findViewById(R.id.editTextCategoria)
        editLocalizacao = findViewById(R.id.editTextLocalizacao)
        editComentario = findViewById(R.id.editTextComentario)
        btnAdicionar = findViewById(R.id.btnAdicionar)
        btnCancelar = findViewById(R.id.btnCancelar)

        val db = AppDatabase.getDatabase(this)

        btnAdicionar.setOnClickListener {
            val titulo = editTitulo.text.toString()
            val dataTexto = editData.text.toString()
            val classificacao = editClassificacao.text.toString().toFloatOrNull()
            val categoria = editCategoria.text.toString()
            val localizacao = editLocalizacao.text.toString()
            val comentario = editComentario.text.toString()

            // Validação básica
            if (titulo.isBlank() || dataTexto.isBlank() || classificacao == null || categoria.isBlank() || localizacao.isBlank()) {
                Toast.makeText(this, "Preencha todos os campos obrigatórios!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Converter data
            val formato = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            val data: Date? = try {
                formato.parse(dataTexto)
            } catch (e: Exception) {
                null
            }

            if (data == null) {
                Toast.makeText(this, "Data inválida. Use o formato dd/MM/yyyy", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val novaViagem = Viagem(
                titulo = titulo,
                data = data,
                classificacao = classificacao,
                categoria = categoria,
                localizacao = localizacao,
                comentario = comentario.ifBlank { null }
            )

            // Inserir no banco
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    db.ViagemDao().inserirViagem(novaViagem)
                }
                Toast.makeText(this@CriarViagens, "Viagem adicionada com sucesso!", Toast.LENGTH_SHORT).show()
                finish() // ou limpar os campos
            }
        }

        btnCancelar.setOnClickListener {
            finish()
        }
    }
}