import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.diarytravel.EditarViagens
import com.example.diarytravel.R
import com.example.diarytravel.VerViagens
import com.example.diarytravel.entities.Viagem

class ViagemAdapter(
    private val viagens: List<Viagem>,
    private val onEdit: (Viagem) -> Unit,
    private val onDelete: (Viagem) -> Unit,
    private val onView: (Viagem) -> Unit
) : RecyclerView.Adapter<ViagemAdapter.ViagemViewHolder>() {

    inner class ViagemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val titulo = view.findViewById<TextView>(R.id.textTitulo)
        val localizacao = view.findViewById<TextView>(R.id.textlocalizacao)
        val btnVer = view.findViewById<ImageButton>(R.id.imageVer)
        val btnEdit = view.findViewById<ImageButton>(R.id.imageEdit)
        val btnDelete = view.findViewById<ImageButton>(R.id.imageDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViagemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.viagensview, parent, false)
        return ViagemViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViagemViewHolder, position: Int) {
        val viagem = viagens[position]
        holder.titulo.text = viagem.titulo
        holder.localizacao.text = viagem.localizacao

        holder.btnVer.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, VerViagens::class.java)
            intent.putExtra("viagem_id", viagem.id)
            context.startActivity(intent)
        }

        holder.btnEdit.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, EditarViagens::class.java)
            intent.putExtra("viagem_id", viagem.id)
            context.startActivity(intent)
        }
        holder.btnDelete.setOnClickListener { onDelete(viagem) }
    }

    override fun getItemCount(): Int = viagens.size
}
